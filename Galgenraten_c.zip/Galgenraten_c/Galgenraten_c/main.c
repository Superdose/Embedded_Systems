/*
 * Galgenraten_c.c
 *
 * Created: 11.08.2021 08:04:50
 * Author : Eric Gr�nler, Christian Crusoveanu, Bruno Krey�ig
 *
 * Einfaches Galgenratenspiel. Durch Bet�tigen von SW2 gelangt man ins Spiel.
 * Wort wird zuf�llig aus wordList ausgew�hlt
 * - SW0 Auswahlbuchstabe inkrementieren
 * - SW1 Auswahlbuchstabe dekrementieren
 * - SW2 (nach Spielstart) Auswahl best�tigen
 * Erneutes Spielen bedarf Aus- und Einschalten des Mikrocontrollers
 */ 
#define F_CPU 3686400					// CPU-Taktrate
#define LIVES_STR "Lives: "				// String-Literal f�r Lebensanzeige
#define MAX_WORD_LENGTH 13				// Maximale Wortl�nge (= 16 - 1 - 2); Zeichen von 0-15; letzte 2 Zeichen abgezogen f�r Buchstabenanzeige
#define TEN_EMPTY "          "			// Zehn leere Zeichen
#define LIVES '8'						// Anzahl Spielerleben

#include <avr/io.h>
#include <util/delay.h>
#include "lcd.h"
#include <avr/interrupt.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>
#include <inttypes.h>

void nextLetter();					// N�chster Buchstabe (A-->B, B-->C, ..., Z-->A)
void prevLetter();					// Vorheriger Buchstabe (B-->A, A-->Z, ..., C-->B)
void render();						// Rendert Displayanzeige, wenn IsGameRunning (Buchstabenauswahl, geratenes Wort, Leben)
void renderWord();					// Aufruf �ber Render; rendert zu erratendes Wort
void renderLose();					// Aufruf �ber Render; rendert Verlust-Emoji
void renderWin();					// Aufruf �ber Render; rendert Sieg-Emoji
void renderStartScreen();			// Rendert intialen Start-Screen
void selectRandomWord();			// Auswahl des zu erratenden Wortes basierend auf Wert von randomNumber
void checkUserInput();				// Aufruf �ber INT2 --> �berpr�fung, ob Wort Buchstabe (letter) enth�lt
void initializeGame();				// Initialisiert lcd-Display und rendert Start-Screen

uint8_t randomNumber = 0;				// Pseudozufallszahl. Wird alle 20ms in main inkrementiert um "Zufall" zu emulieren
bool IsGameRunning;					// wird in initializeGame() auf false gesetzt und nach dem ersten Bet�tigen von SW2 auf true
char word[MAX_WORD_LENGTH];			// das zu erratende Wort (zuf�llig aus wordList selektiert)

// Wortliste aller m�glichen Zufallsw�rter
char wordList[][MAX_WORD_LENGTH] =	
{
	"Stuhl", "Amerika", "Deutschland", "Basketball", "Drohne", "Kripfganz", "Cisco", "Jaeger", "Sammler",
	"Jochen", "Broetchen", "Schachtel", "Bildschirm", "Tastatur", "Maus", "Rechner", "Kabel", "Brille", 
	"Waschbecken", "Seife", "Desinfektion", "Spannung", "Papierkorb", "Webex", "Beamer", "Matrix", "Tuer",
	"Tafel", "Lichtschalter", "Java", "Python", "Firewall", "NAT", "Cobol", "Fortran", "Force", "Cybop",
	"Lampe", "Decke", "Wand", "Rohr", "Wasserhahn", "Blender", "Unity", "Dialyse", "Chirurg", "Homeopathie",
	"Maske", "Corona", "LED", "Netzteil", "Grafikkarte", "RAM", "ALU", "Widerstand", "Transistor", "Stromstaerke",
	"Olympia", "Belarus", "Flugzeug", "Szenario", "Besuch", "Galgenraten", "Bizeps", "Trizeps", "Quadrizeps",
	"Adresse", "Ethernet", "Internet", "Segmentierung", "Fragmentieren"
};

char wordProgress[MAX_WORD_LENGTH] = "";			// Rate-Fortschritt des Spielers (nicht erratene Buchstaben mit "_" ersetzt)

char letter = 'A';									// Aktuell ausgew�hlter Buchstabe
char lives = LIVES;									// Aktuelle Lebenspunkte

ISR(INT0_vect)		// Interruptroutine f�r INT0 --> PD2 (SW0)
{
	if (IsGameRunning == true) 
	{
		nextLetter();
		render();
		_delay_ms(100);			// ggf. nicht mehr exakt 100 ms
		GIFR &= ~(1<<INTF0);	// Entprellen: weitere angemeldete INT0 l�schen
	}
	
}

ISR(INT1_vect)		// Interruptroutine f�r INT1 --> PD3 (SW1)
{
	if (IsGameRunning == true) 
	{
		prevLetter();
		render();
		_delay_ms(100);			// ggf. nicht mehr exakt 100 ms
		GIFR &= ~(1<<INTF1);	// Entprellen: weitere angemeldete INT1 l�schen
	}
	
}

// Confirm Input Interrupt
ISR(INT2_vect)		// Interruptroutine f�r INT2 --> PB2 (SW3)
{
	if (IsGameRunning) checkUserInput();
	else initializeGame();		
		
	render();
		
	_delay_ms(100);			// ggf. nicht mehr exakt 100 ms
	GIFR &= ~(1<<INTF2);	// Entprellen: weitere angemeldete INT2 l�schen
}

void checkUserInput()
{
	int i = 0;
	
	int wordLength = strlen(word);
	bool IsLosingLife = true;
	
	while(i < wordLength)
	{
		if (word[i] == letter)
		{
			
			wordProgress[i] = letter;
			IsLosingLife = false;
		}
		i++;
	}
	
	if (IsLosingLife)
	{
		lives--;
		if (lives < '0') lives = '0';
	}
	
}

void initializeGame()
{
		selectRandomWord();
		int i = 0;
		while (i < strlen(word))
		{
			wordProgress[i] = '_';
			i++;
		}
		wordProgress[i+1] = '\0';
		lcd_setcursor(0,0);
		lcd_string(TEN_EMPTY);
		IsGameRunning = true;
	
}

void render() 
{
	lcd_setcursor(14,0);
	lcd_data('|');
	lcd_setcursor(14,1);
	lcd_data('|');
	lcd_setcursor(15,0);
	lcd_data(letter);
	
	lcd_setcursor(0,1);
	lcd_string(LIVES_STR);
	lcd_setcursor(strlen(LIVES_STR) , 1);
	lcd_data(lives);	
	
	// wenn wordProgress == word, dann wurden alle "_" erfolgreich ersetzt
	if (strcmp(wordProgress, word) == 0) renderWin();
	else if (lives > '0') renderWord();
	else renderLose();
		
}

void renderWord() 
{
	lcd_setcursor(0,0);
	lcd_string(wordProgress);
	
}

void renderWin()
{
	lcd_setcursor(0,0);
	lcd_string(strcat(":-)", TEN_EMPTY));
}

void renderLose()
{
	lcd_setcursor(0,0);
	lcd_string(strcat(":-(", TEN_EMPTY));
}


void nextLetter() {
	if (letter == 'Z') letter  = 'A';
	else letter ++;

}
void prevLetter() {
	if (letter == 'A') letter  = 'Z';
	else letter--;		
	
}
void init() 
{
	lcd_init();
	renderStartScreen();
	IsGameRunning = false;
}

void renderStartScreen()
{
	lcd_clear();
	lcd_setcursor(0,0);
	lcd_string("Press SW2");
	lcd_setcursor(0,1);
	lcd_string("to start");
}

void selectRandomWord() 
{
	// L�nge 2D-Array = sizeof(array) / Byte-Gr��e der Sub-Arrays
	int arrLength = sizeof(wordList) / MAX_WORD_LENGTH;
	
	strcpy(word, wordList[randomNumber % arrLength]);
	
	int i;
	for (i = 0; i < sizeof(word); i++)
	{
		word[i] = toupper(word[i]);
	}
}


int main(void)
{
	// INT0 aktivieren
	MCUCR |=  (1<<ISC01);
	MCUCR &= ~(1<<ISC00);	// fallende Flanke erzeugt Interrupt
	GICR  |=  (1<<INT0);	// INT0 zulassen
	// INT1 aktivieren
	MCUCR |=  (1<<ISC11);
	MCUCR &= ~(1<<ISC10);	// fallende Flanke erzeugt Interrupt
	GICR  |=  (1<<INT1);	// INT1 zulassen
	
	PORTB = 0x04;           // Aktiviere Port B
	MCUCSR |= (1 << ISC2);	// fallende Flanke erzeugt Interrupt
	GICR  |= (1 << INT2);   // INT2 zulassen
	
	//Interrupts global zulassen
	sei();
	
	init();

	while(1)
	{
		// "Erzeugung Zufallszahl"
		_delay_ms(20);
		randomNumber++;	
	}

	return 0;
   
}

